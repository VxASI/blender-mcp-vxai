#!/bin/bash
# Activate the virtual environment
source /Users/chiragawale/Documents/GitHub/blender-mcp-vxai/venv/bin/activate
# Run the server with the virtual environment's Python
exec /Users/chiragawale/Documents/GitHub/blender-mcp-vxai/venv/bin/python3 /Users/chiragawale/Documents/GitHub/blender-mcp-vxai/blender_mcp_vxai/server.py